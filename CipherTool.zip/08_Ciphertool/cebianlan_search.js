
/* 这是侧边栏搜索定位功能 */

document.addEventListener('DOMContentLoaded', () => {
const searchInput = document.getElementById('cardSearch');
const cards = document.querySelectorAll('.card');
searchInput.addEventListener('keydown', (event) => { 
    if (event.key === 'Enter') {
        event.preventDefault(); 
        const searchTerm = searchInput.value.toLowerCase();
        let foundCard = null;
        cards.forEach(card => {const badge = card.querySelector('.badge');
            if (badge) {const cardTitle = badge.textContent.toLowerCase();
                if (cardTitle.includes(searchTerm)) {if (!foundCard) {foundCard = card;}}
            }});
        if (foundCard) {
            foundCard.scrollIntoView({ behavior: 'smooth', block: 'center' }); 
            foundCard.classList.add('card-highlight');
            setTimeout(() => {foundCard.classList.remove('card-highlight');}, 5000);
        }}});
    });