        // 实时更新函数
function updateAll() {
    const text = document.getElementById('mainInput').value;
    if (!text) {document.querySelectorAll('.result').forEach(el => el.textContent = ''); return;}
    
    // 凯撒密码
    const shift = parseInt(document.getElementById('caesarShift').value) || 3;
    const caesarEncrypted = CaesarCipher.encrypt(text, shift);
    const caesarDecrypted = CaesarCipher.decrypt(text, shift); 
    document.getElementById('caesarResult').textContent =
        `加密: ${caesarEncrypted}\n解密: ${caesarDecrypted}`;

    // 维吉尼亚密码
    const vigenereKey = document.getElementById('vigenereKey').value || 'KEY';
    const vigenereEncrypted = VigenereCipher.encrypt(text, vigenereKey);
    const vigenereDecrypted = VigenereCipher.decrypt(text, vigenereKey); 
    document.getElementById('vigenereResult').textContent =
        `加密: ${vigenereEncrypted}\n解密: ${vigenereDecrypted}`;

    // 栅栏密码
    const rails = parseInt(document.getElementById('railCount').value) || 3;
    const railEncrypted = RailFenceCipher.encrypt(text, rails);
    const railDecrypted = RailFenceCipher.decrypt(text, rails); 
    document.getElementById('railResult').textContent =
        `加密: ${railEncrypted}\n解密: ${railDecrypted}`;
    
    // AtBash
    const atbashEncrypted = AtBashCipher.encrypt(text);
    document.getElementById('atbashResult').textContent =
        `解密: ${atbashEncrypted}`;
    
    // 进制转换
    const fromBase = parseInt(document.getElementById('fromBase').value) || 10;
    const toBase = parseInt(document.getElementById('toBase').value) || 2;
    document.getElementById('baseResult').textContent =
        BaseConverter.convert(text, fromBase, toBase);
    
    // 摩尔斯电码
    const morseEncrypted = MorseCode.encrypt(text);
    const morseDecrypted = MorseCode.decrypt(text); 
    document.getElementById('morseResult').textContent =
        `加密: ${morseEncrypted}\n解密: ${morseDecrypted}`;
    
    // 手机九键
    const phoneEncrypted = PhoneKeyCipher.encrypt(text);
    const phoneDecrypted = PhoneKeyCipher.decrypt(text); 
    document.getElementById('phoneResult').textContent =
        `加密: ${phoneEncrypted}\n解密: ${phoneDecrypted}`;

    // 比尔密码
    const bealeKey = document.getElementById('bealeKey').value;
    const bealeEncrypted = BealeCipher.encrypt(text, bealeKey);
    //const bealeDecrypted = BealeCipher.decrypt(text, bealeKey); // decrypt函数未实现，仅占位作预留)
    document.getElementById('bealeResult').textContent =
        `解密: ${bealeEncrypted}`;

    // 反切码
    const fanqieCode = FanqieCipher.encrypt(text); 
    const fanqieDecrypted = FanqieCipher.decrypt(text); 
    document.getElementById('fanqieResult').textContent =
        `解密: ${fanqieCode}\n加密: ${fanqieDecrypted}`; 

    // mRNA序列
    const dnaEncrypted = DnaCipher.encrypt(text); 
    const dnaDecrypted = DnaCipher.decrypt(text); 
    document.getElementById('dnaResult').textContent =
        `解密: ${dnaEncrypted}\n加密: ${dnaDecrypted}`;

    // V字键盘
    const vKeyboardEncrypted = VKeyboardCipher.encrypt(text); 
    const vKeyboardDecrypted = VKeyboardCipher.decrypt(text); 
    document.getElementById('vKeyboardResult').textContent =
        `解密: ${vKeyboardDecrypted}\n加密: ${vKeyboardEncrypted}`; 

    // QWE密码
    const qweEncrypted = QweCipher.encrypt(text); 
    const qweDecrypted = QweCipher.decrypt(text); 
    document.getElementById('qweResult').textContent =
        `解密: ${qweEncrypted}\n加密: ${qweDecrypted}`; 

    // Bacon 密码
    const baconEncrypted = BaconCipher.encrypt(text); 
    const baconDecrypted = BaconCipher.decrypt(text); 
    document.getElementById('baconResult').textContent =
        `加密: ${baconEncrypted}\n解密: ${baconDecrypted}`;

    // 柱状栅栏密码
    const columnarRails = parseInt(document.getElementById('columnarRailCount').value);
    const columnarRailEncrypted = ColumnarRailCipher.encrypt(text, columnarRails);
    const columnarRailDecrypted = ColumnarRailCipher.decrypt(text, columnarRails);
    document.getElementById('columnarRailResult').textContent =
        `加密: ${columnarRailEncrypted}\n解密: ${columnarRailDecrypted}`;

    // W型栅栏密码
    const wRails = parseInt(document.getElementById('wRailCount').value);
    const wRailEncrypted = WShapeRailFenceCipher.encrypt(text, wRails);
    const wRailDecrypted = WShapeRailFenceCipher.decrypt(text, wRails);
    document.getElementById('wRailResult').textContent =
        `加密: ${wRailEncrypted}\n解密: ${wRailDecrypted}`;

    // 01248密码
    const cipher01248Encrypted = Cipher01248.encrypt(text);
    const cipher01248Decrypted = Cipher01248.decrypt(text);
    document.getElementById('cipher01248Result').textContent =
        `加密: ${cipher01248Encrypted}\n解密: ${cipher01248Decrypted}`;

    // 元音密码
    const vowelCipherEncrypted = VowelCipher.encrypt(text);
    const vowelCipherDecrypted = VowelCipher.decrypt(text);
    document.getElementById('vowelCipherResult').textContent =
        `加密: ${vowelCipherEncrypted}\n解密: ${vowelCipherDecrypted}`;

    // ASCII 转换
    const inputType = document.getElementById('asciiInputType').value;
    const outputType = document.getElementById('asciiOutputType').value;
    const asciiConverted = ASCIIHandler.convert(text, inputType, outputType);
    document.getElementById('asciiResult').textContent = 
        `结果: ${asciiConverted}`;

	// 中文电码转换
	if (CCCHandler) { 
		const cccText = document.getElementById('mainInput').value; 
		const cccConverted = CCCHandler.convert(cccText);
		document.getElementById('cccResult').textContent =`结果: ${cccConverted}`;} 
    else {document.getElementById('cccResult').textContent =`中文电码功能加载失败`; }
            
    // ROT 转换
    const rotOutputType = document.getElementById('rotOutputType').value;
    const rotEncrypted = ROTCipher.encrypt(text, rotOutputType);
    document.getElementById('rotResult').textContent =
        `结果: ${rotEncrypted}`;
    
}

// 事件监听
document.getElementById('mainInput').addEventListener('input', updateAll); 
document.querySelectorAll('input, textarea, select').forEach(el => {el.addEventListener('input', updateAll);});

// 初始化
updateAll();
