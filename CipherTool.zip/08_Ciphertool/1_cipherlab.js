// 凯撒加密算法实现
class CaesarCipher {
    static encrypt(text, shift) {
        shift = parseInt(shift) || 3;
        return text.split('').map(char => {
            if (char.match(/[a-zA-Z]/)) {
                const code = char.charCodeAt(0);
                const isUpperCase = code >= 65 && code <= 90;
                const base = isUpperCase ? 65 : 97;
                return String.fromCharCode((code - base + shift) % 26 + base);
            }
            return char;
        }).join('');
    }
    static decrypt(text, shift) { 
        shift = parseInt(shift) || 3;
        return text.split('').map(char => {
            if (char.match(/[a-zA-Z]/)) {
                const code = char.charCodeAt(0);
                const isUpperCase = code >= 65 && code <= 90;
                const base = isUpperCase ? 65 : 97;
                return String.fromCharCode((code - base - shift + 26) % 26 + base); 
            }
            return char;
        }).join('');
    }
}

// 维吉尼亚密码
class VigenereCipher {
    static encrypt(text, key) {
        if (!key) key = 'KEY'; key = key.toUpperCase(); let result = ''; let keyIndex = 0;
        for (let char of text) {
            if (char.match(/[a-zA-Z]/)) {
                const isUpperCase = char === char.toUpperCase(); char = char.toUpperCase();
                const shift = key[keyIndex % key.length].charCodeAt(0) - 65;
                let newChar = String.fromCharCode((char.charCodeAt(0) - 65 + shift) % 26 + 65);
                result += isUpperCase ? newChar : newChar.toLowerCase(); keyIndex++;} else {result += char;}
        } return result;
    }
    
    static decrypt(text, key) {
        if (!key) key = 'KEY'; key = key.toUpperCase(); let result = ''; let keyIndex = 0;
        for (let char of text) {
            if (char.match(/[a-zA-Z]/)) {
                const isUpperCase = char === char.toUpperCase(); char = char.toUpperCase();
                const shift = key[keyIndex % key.length].charCodeAt(0) - 65;
                let newChar = String.fromCharCode((char.charCodeAt(0) - 65 - shift + 26) % 26 + 65);
                result += isUpperCase ? newChar : newChar.toLowerCase();
                keyIndex++;} else {result += char;}
        } return result;
    }
}

//  栅栏密码
class RailFenceCipher {
    static encrypt(text, rails) {
        rails = parseInt(rails) || 3;
        if (rails < 2) rails = 2; if (!text) return ''; 
        text = text.replace(/\s/g, '');
        const fence = Array.from({length: rails}, () => []); let rail = 0, dir = 1;
        for (let char of text) {fence[rail].push(char); rail += dir; if (rail === rails - 1 || rail === 0) dir *= -1;}
        return fence.flat().join('');
    }
    static decrypt(text, rails) {
        rails = parseInt(rails) || 3;
        if (rails < 2) rails = 2; if (!text) return '';
        text = text.replace(/\s/g, '');
        const fence = Array.from({length: rails}, () => Array(text.length).fill(null));let rail = 0, dir = 1;
        for (let i = 0; i < text.length; i++) {fence[rail][i] = true; rail += dir; if (rail === rails - 1 || rail === 0) dir *= -1;} let index = 0;
        for (let i = 0; i < rails; i++) {for (let j = 0; j < text.length; j++) {if (fence[i][j] === true) {fence[i][j] = text[index++];}}} let result = ''; rail = 0;dir = 1;
        for (let i = 0; i < text.length; i++) {result += fence[rail][i]; rail += dir; if (rail === rails - 1 || rail === 0) dir *= -1;}
        return result;
    }
}

// AtBash码
class AtBashCipher {
    static encrypt(text) {
        return text.split('').map(char => {
            if (char.match(/[a-zA-Z]/)) {
                const isUpperCase = char === char.toUpperCase();
                const code = char.toUpperCase().charCodeAt(0);
                const newChar = String.fromCharCode(90 - (code - 65));
                return isUpperCase ? newChar : newChar.toLowerCase();
            }
            return char;
        }).join('');
    }
    static decrypt(text) {return this.encrypt(text);}
}

// 进制转换
class BaseConverter {
    static CHAR_SET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static convert(input, fromBase, toBase) {
        try {
            if (fromBase < 2 || fromBase > 36 || toBase < 2 || toBase > 36) {throw new Error("进制范围2-36");}
            return input.split(' ').map(num => {
                const decimal = parseInt(num, fromBase);
                if (isNaN(decimal)) throw new Error("无效输入");
                if (toBase === 1) return '0'.repeat(decimal);
                if (decimal === 0) return '0'; let result = []; let n = decimal;
                while (n > 0) {result.push(this.CHAR_SET[n % toBase]); n = Math.floor(n / toBase);}
                return result.reverse().join('');
            }).join(' ');
        } catch (e) {return `错误: ${e.message}`;}
    }
}

//  摩尔斯电码
class MorseCode {
    static morseDict = {
        'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
        'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
        'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
        'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
        'Y': '-.--', 'Z': '--..', '1': '.----', '2': '..---', '3': '...--',
        '4': '....-', '5': '.....', '6': '-....', '7': '--...', '8': '---..',
        '9': '----.', '0': '-----', ' ': '/'
    };
    static encrypt(text) {return text.toUpperCase().split('').map(char => this.morseDict[char] || char).join(' ');}
    static decrypt(text) {
        const reverseMorse = Object.fromEntries(Object.entries(this.morseDict).map(([key, value]) => [value, key]));
        return text.split(' ').map(code => reverseMorse[code] || code).join('');
    }
}

//  手机九键
class PhoneKeyCipher {
    static phoneDict = {
        'A': '21', 'B': '22', 'C': '23', 'D': '31', 'E': '32', 'F': '33', 'G': '41', 'H': '42', 'I': '43',
        'J': '51', 'K': '52', 'L': '53', 'M': '61', 'N': '62', 'O': '63', 'P': '71', 'Q': '72', 'R': '73', 
        'S': '74', 'T': '81', 'U': '82', 'V': '83', 'W': '91', 'X': '92', 'Y': '93', 'Z': '94', ' ': '0'
    };
    static encrypt(text) {return text.toUpperCase().split('').map(char => this.phoneDict[char] || char).join(' ');}
    static decrypt(text) {
        const reversePhone = Object.fromEntries(Object.entries(this.phoneDict).map(([key, value]) => [value, key]));
        return text.split(' ').map(code => reversePhone[code] || code).join('');
    }
}

//  比尔密码
class BealeCipher {
    static encrypt(text, key) {
        if (!text) return '';
        if (!key) return '请提供数字密钥(用空格隔开)'; 
        const words = text.split(/\s+/); 
        const firstLetters = words.map(word => word[0] || ''); 
        const firstLettersStr = firstLetters.join(''); 
        const keys = key.split(/\s+/).map(Number).filter(Number.isInteger); 
        if (keys.length === 0) return '无效密钥'; 
        if (keys.length > firstLettersStr.length) return '密钥过长'; let result = [];
        for (let i = 0; i < keys.length; i++) {const keyIndex = keys[i];
            if (keyIndex >= 1 && keyIndex <= firstLettersStr.length) { 
                result.push(firstLettersStr[keyIndex - 1]); } else {return '密钥超出范围'; }
        }   return result.join('');
    }
    static decrypt(text, key) {
        //  加密功能暂时无法实现，先做个预留
        return '预留';
    }
}

// 反切码
class FanqieCipher {
    static initials = { // 声母表 
        '1': 'l', '2': 'b','3': 'q', '4': 'd', '5': 'b', '6': 't', '7': 'zh', '8': 'r', '9': 'sh', '11': 'y', '12': 'm', '13': 'y', '14': 'ch', '15': 'x', '16': 'd', '17': 'zh', '18': 'y', '19': 'j', '20': 'zh'
    };
    static finals = { // 韵母表 
        '1': 'un', '2': 'ua', '3': 'iang', '4': 'iu', '5': 'an', '6': 'ai', '7': 'ia', '8': 'in', '9': 'uan', '10': 'e', '11': 'v', '12': 'in', '13': 'ei', '14': 'u', '15': 'eng', '16': 'uang', '17': 'ui', '18': 'ao', '19': 'in', '20': 'ang', '22': 'ong', '23': 'iao', '24': 'uo', '25': 'i', '26': 'iao', '27': 'i', '28': 'eng', '29': 'ui', '30': 'u', '31': 'ian', '32': 'i', '33': 'ei', '34': 'ai', '35': 'e', '36': 'ou'
    };
    static encrypt(fanqieCode) { 
        if (!fanqieCode) return '';
        const pairs = fanqieCode.trim().split(/\s+/); 
        let result = [];
        for (const pair of pairs) {
            const [initialCode, finalCode] = pair.split(/[\/-]/); 
            const initial = this.initials[initialCode];
            const final = this.finals[finalCode];
            if (initial && final) {result.push(initial + final); } else {return `输入编号，如：15/8 或 15-8 `; }
        }   return result.join(' '); 
    }
    static decrypt(pinyinText) { 
        if (!pinyinText) return '';
        const pinyinWords = pinyinText.trim().split(/\s+/); let result = [];
        const reverseInitials = this.reverseLookup(this.initials); 
        const reverseFinals = this.reverseLookup(this.finals); 
        for (const word of pinyinWords) {
            let initialCode = '', finalCode = '';
            let found = false;
            for (const initialPinyin in reverseInitials) {
                if (word.startsWith(initialPinyin)) { 
                    const finalPinyin = word.substring(initialPinyin.length); 
                    if (reverseFinals[finalPinyin]) { 
                        initialCode = reverseInitials[initialPinyin]; 
                        finalCode = reverseFinals[finalPinyin]; 
                        result.push(`${initialCode}/${finalCode}`); 
                        found = true; break; 
                    }
                }
            }
            if (!found) {if (reverseFinals[word]) {finalCode = reverseFinals[word]; result.push(`0/${finalCode}`); found = true;}}
            if (!found) {return `输入拼音，如：liu bian`; }
        }   return result.join(' '); 
    }
    static reverseLookup(table) {const reversedTable = {}; for (const code in table) {reversedTable[table[code]] = code;}
        return reversedTable;
    }
}

// mRNA序列
class DnaCipher {
    static dnaMap = { // mRNA序列密码表
        'GCU': 'A', 'GCC': 'A', 'GCA': 'B', 'GCG': 'B', 'UGU': 'C', 'UGC': 'C', 'GAU': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E', 'UUU': 'F', 'UUC': 'F',
        'GGU': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G', 'CAU': 'H', 'AUU': 'I', 'AUC': 'I', 'AUA': 'I', 'AGA': 'J', 'AGG': 'J', 'AAA': 'K', 'AAG': 'K', 
        'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L', 'AUG': 'M', 'AAU': 'N', 'AAC': 'N', 'CCA': 'O', 'CCG': 'O', 'CCU': 'P', 'CCC': 'P', 'CAA': 'Q', 
        'CAG': 'Q', 'CGU': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R', 'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S', 'AGU': 'S', 'AGC': 'S', 'ACU': 'T', 
        'ACC': 'T', 'ACA': 'T', 'ACG': 'T', 'UUA': 'U', 'UUG': 'U', 'GUU': 'V', 'GUC': 'V', 'UGG': 'W', 'GUA': 'X', 'GUG': 'X', 'UAU': 'Y', 'UAC': 'Y', 
        'CAC': 'Z'
    };
    static encrypt(dnaSequence) { 
        if (!dnaSequence) return '';
        const codons = dnaSequence.trim().split(/\s+/); let result = [];
        for (const codon of codons) {
            const letter = this.dnaMap[codon]; 
            if (letter) {result.push(letter); } 
            else {return `请输入正确密码子，如:GCU`; }
        }   return result.join(''); 
    }
    static decrypt(text) { 
        if (!text) return '';
        const letters = text.toUpperCase().split(''); let result = [];
        const reverseDnaMap = this.reverseLookup(this.dnaMap); 
        for (const letter of letters) {const codon = reverseDnaMap[letter]; 
            if (codon) {result.push(codon); } else {return ` `; }
        }   return result.join(' '); 
    }
    static reverseLookup(table) { 
        const reversedTable = {};
        for (const code in table) {reversedTable[table[code]] = code;}
        return reversedTable;
    }
}


// V字键盘
class VKeyboardCipher {
    static keyboardMap = {
        '12': 'q', '23': 'w', '34': 'e', '45': 'r', '56': 't', '67': 'y', '78': 'u', '89': 'i', '90': 'o', '13': 'a', '24': 's', '35': 'd', '46': 'f', '57': 'g', '68': 'h', '79': 'j', '80': 'k', '14': 'z', '25': 'x', '36': 'c', '47': 'v', '58': 'b', '69': 'n', '70': 'm'
    };
    static encrypt(text) { 
        if (!text) return '';
        const letters = text.toLowerCase().split(''); 
        let result = [];
        const reverseKeyboardMap = this.reverseLookup(this.keyboardMap); 
        for (const letter of letters) {
            const code = reverseKeyboardMap[letter]; 
            if (code) {result.push(code); } else if (letter === ' ') {result.push(' '); }
            else {return `V字键盘表不存在此字符 ${letter}`; }
        }   return result.join(' '); 
    }
    static decrypt(numericalCode) { 
        if (!numericalCode) return '';
        const codes = numericalCode.trim().split(/\s+/); 
        let result = [];
        for (const code of codes) {
            const letter = this.keyboardMap[code]; 
            if (letter) {result.push(letter); } else if (code === '') {result.push(' '); }
            else {return `${code}`; }
        }   return result.join(''); 
    }
    static reverseLookup(table) { 
        const reversedTable = {};
        for (const code in table) {reversedTable[table[code]] = code;}
        return reversedTable;
    }
}

// QWE密码
class QweCipher {
    static keyboardMap = {
        'q': 'a', 'w': 'b', 'e': 'c', 'r': 'd', 't': 'e', 'y': 'f', 'u': 'g', 'i': 'h', 'o': 'i', 'p': 'j',
        'a': 'k', 's': 'l', 'd': 'm', 'f': 'n', 'g': 'o', 'h': 'p', 'j': 'q', 'k': 'r', 'l': 's',
        'z': 't', 'x': 'u', 'c': 'v', 'v': 'w', 'b': 'x', 'n': 'y', 'm': 'z'
    };
    static encrypt(text) { 
        if (!text) return '';
        const letters = text.toLowerCase().split(''); 
        let result = [];
        for (const letter of letters) {
            const code = this.keyboardMap[letter]; 
            if (code) {result.push(code); } 
            else if (letter === ' ') {result.push(' '); }
            else {console.log("QWE Cipher Encrypt - Invalid letter:", letter); return ` `;}
        }   return result.join(''); }
    static decrypt(text) { 
        if (!text) return '';
        const letters = text.toLowerCase().split(''); let result = [];
        const reverseKeyboardMap = this.reverseLookup(this.keyboardMap); 
        for (const letter of letters) {
            const code = reverseKeyboardMap[letter]; 
            if (code) {result.push(code); } 
            else if (letter === ' ') {result.push(' '); }
            else {console.log("QWE Cipher Decrypt - Invalid letter: ", letter); return ` `;}
        }   return result.join(''); }
    static reverseLookup(table) { 
        const reversedTable = {};
        for (const code in table) {reversedTable[table[code]] = code;}
        return reversedTable;
    }
}

//培根密码
class BaconCipher {
    static baconMap = { 
        'A': 'aaaaa', 'B': 'aaaab', 'C': 'aaaba', 'D': 'aaabb', 'E': 'aabaa',
        'F': 'aabab', 'G': 'aabba', 'H': 'aabbb', 'I': 'abaaa', 'K': 'ababa',
        'L': 'ababb', 'M': 'abbaa', 'N': 'abbab', 'O': 'abbba', 'P': 'abbbb',
        'Q': 'baaaa', 'R': 'baaab', 'S': 'baaba', 'T': 'baabb', 'U': 'babaa',
        'V': 'babab', 'W': 'babba', 'X': 'babbb', 'Y': 'bbaaa', 'Z': 'bbaab',
        '0': 'abbba', '1': 'aaaaa', '2': 'aaaab', '3': 'aaaba', '4': 'aaabb',
        '5': 'aabaa', '6': 'aabab', '7': 'aabba', '8': 'aabbb', '9': 'abaaa'
        // 没有J 
    };
    static encrypt(text) {text = text.toUpperCase(); let result = '';
        for (let char of text) {
            if (this.baconMap[char]) {result += this.baconMap[char] + ' ';} 
            else if (char === ' ') {result += ' '; }
        }   return result.trim().toLowerCase(); 
    }
    static decrypt(text) {
        text = text.replace(/[^ab\s]/g, '').toLowerCase(); 
        const chunks = text.split(/\s+/).filter(chunk => chunk.length === 5); let result = '';
        const reverseBaconMap = Object.fromEntries(Object.entries(this.baconMap).map(([key, value]) => [value, key])); 
        for (let chunk of chunks) {
            if (reverseBaconMap[chunk]) {result += reverseBaconMap[chunk];}
        }   return result.toLowerCase(); 
    }
}

// 柱状栅栏 (实际上是柱状转置密码)
class ColumnarRailCipher {
    static encrypt(text, columns) {
        columns = parseInt(columns) || 2;
        if (columns < 2) columns = 2;
        if (!text) return '';
        text = text.replace(/\s/g, '');
        const textLength = text.length;
        const rows = Math.ceil(textLength / columns);
        const grid = Array.from({ length: rows }, () => Array(columns).fill(''));
        let textIndex = 0;
        for (let i = 0; i < rows; i++) {for (let j = 0; j < columns; j++) {if (textIndex < textLength) {grid[i][j] = text[textIndex++];}}}
        let encryptedText = '';
        for (let j = 0; j < columns; j++) {for (let i = 0; i < rows; i++) {encryptedText += grid[i][j];}}
        return encryptedText;
    }
    static decrypt(ciphertext, columns) {
        columns = parseInt(columns) || 2;
        if (columns < 2) columns = 2;
        if (!ciphertext) return '';
        ciphertext = ciphertext.replace(/\s/g, '');
        const ciphertextLength = ciphertext.length;
        const rows = Math.ceil(ciphertextLength / columns);
        const grid = Array.from({ length: rows }, () => Array(columns).fill(''));
        let textIndex = 0;
        for (let j = 0; j < columns; j++) {for (let i = 0; i < rows; i++) {if (textIndex < ciphertextLength) {grid[i][j] = ciphertext[textIndex++];}}}
        let decryptedText = '';
        for (let i = 0; i < rows; i++) {for (let j = 0; j < columns; j++) {decryptedText += grid[i][j];}}
        return decryptedText;
    }
}

// W型栅栏
class WShapeRailFenceCipher {
    static encrypt(text, rails) {
        rails = parseInt(rails) || 3;
        if (rails < 2) rails = 2;
        if (!text) return '';
        const fence = Array.from({ length: rails }, () => []); let rail = 0; let direction = 1; 
        for (const char of text) {
            fence[rail].push(char); rail += direction;
            if (rail === rails) {direction = -1; rail = rails - 2;
                if (rail < 0) rail = 0; } 
                else if (rail < 0) {direction = 1; rail = 1;}
        }   return fence.flat().join('');
    }
    static decrypt(ciphertext, rails) {
        rails = parseInt(rails) || 3;
        if (rails < 2) rails = 2;
        if (!ciphertext) return '';
        const fence = Array.from({ length: rails }, () => []); let rail = 0; let direction = 1;
        const positions = []; for (let i = 0; i < ciphertext.length; i++) {
            positions.push(rail);
            rail += direction;
            if (rail === rails) { direction = -1; rail = rails - 2;
                if (rail < 0) rail = 0;} else if (rail < 0) {direction = 1; rail = 1;}
        }
        const railsCharCounts = Array(rails).fill(0); 
        for (const pos of positions) {railsCharCounts[pos]++;} let cipherIndex = 0;
        for (let i = 0; i < rails; i++) {
            fence[i] = ciphertext.slice(cipherIndex, cipherIndex + railsCharCounts[i]).split(''); 
            cipherIndex += railsCharCounts[i]; 
        }
        let decryptedText = ''; rail = 0; direction = 1;
        let fenceIndexCounter = Array(rails).fill(0); 
        for (let i = 0; i < ciphertext.length; i++) {
            decryptedText += fence[rail][fenceIndexCounter[rail]++];
            rail += direction;
            if (rail === rails) {direction = -1; rail = rails - 2; if (rail < 0) rail = 0;} 
            else if (rail < 0) {direction = 1; rail = 1;}
        }   return decryptedText;
    }
}

// 01248 密码
class Cipher01248 {
    static encrypt(text) {
        if (!text) return '';
        text = text.toUpperCase(); let encryptedText = '';
        for (let i = 0; i < text.length; i++) {
            const charCode = text.charCodeAt(i);
            if (charCode >= 65 && charCode <= 90) {let num = charCode - 64; let segment = '';
                const values = [8, 4, 2, 1];
                for (const val of values) {while (num >= val) {segment += val; num -= val;}}   
                encryptedText += segment + '0'; }
        }   return encryptedText.slice(0, -1); // 移除末尾多余的 '0'
    }
    static decrypt(ciphertext) {
        if (!ciphertext) return '';
        let decryptedText = '';
        const segments = ciphertext.split('0');
        for (const segment of segments) {
            let sum = 0;
            for (const digit of segment) {sum += parseInt(digit);}
            if (sum > 0 && sum <= 26) {decryptedText += String.fromCharCode(sum + 64); }
        }   return decryptedText;
    }
}

// 元音密码
class VowelCipher {
    static encrypt(text) {
        if (!text) return '';
        text = text.toUpperCase();
        const encryptionMap = {
            'A': '1', 'B': '11', 'C': '12', 'D': '13', 'E': '2', 'F': '21', 'G': '22', 'H': '23', 'I': '3',
            'J': '31', 'K': '32', 'L': '33', 'M': '34', 'N': '35', 'O': '4', 'P': '41', 'Q': '42', 'R': '43',
            'S': '44', 'T': '45', 'U': '5', 'V': '51', 'W': '52', 'X': '53', 'Y': '54', 'Z': '55'
        };
        let encryptedText = '';
        for (let char of text) {
            if (encryptionMap[char]) {encryptedText += encryptionMap[char] + ' '; } 
            else {encryptedText += char; }
        }   return encryptedText.trim();                    
    }
    static decrypt(ciphertext) {
        if (!ciphertext) return '';
        const decryptionMap = {
            '1': 'A', '11': 'B', '12': 'C', '13': 'D', '2': 'E', '21': 'F', '22': 'G', '23': 'H', '3': 'I',
            '31': 'J', '32': 'K', '33': 'L', '34': 'M', '35': 'N', '4': 'O', '41': 'P', '42': 'Q', '43': 'R',
            '44': 'S', '45': 'T', '5': 'U', '51': 'V', '52': 'W', '53': 'X', '54': 'Y', '55': 'Z'
        };
        let decryptedText = '';
        const codes = ciphertext.split(/\s+/); 
        for (let code of codes) {
            if (decryptionMap[code]) {decryptedText += decryptionMap[code];} 
            else {decryptedText += code + ' '; }
        }   return decryptedText.trim(); 
    }
}

// ASCII码转换逻辑
const ASCIIHandler = {
    convert(text, inputType, outputType) {
        if (inputType === outputType) return text; 
        let decimals = [];
        switch (inputType) {
            case 'char': decimals = [...text].map(c => c.charCodeAt(0)); break;
            case 'dec': decimals = text.split(/[ ,]/).filter(Boolean).map(Number); break;
            case 'hex': decimals = text.split(/[ ,]/).filter(Boolean).map(h => parseInt(h, 16)); break;
            case 'oct': decimals = text.split(/[ ,]/).filter(Boolean).map(o => parseInt(o, 8)); break;
            case 'bin': decimals = text.split(/[ ,]/).filter(Boolean).map(b => parseInt(b, 2)); break;
        }
        return decimals.map(d => {
            if (isNaN(d)) return '请输入正确字符'; 
            switch (outputType) {
                case 'char': return String.fromCharCode(d);
                case 'dec': return d.toString(10);
                case 'hex': return d.toString(16).toUpperCase();
                case 'oct': return d.toString(8);
                case 'bin': return d.toString(2).padStart(8, '0'); 
            }
        }).join(' ');
    }
};

// 中文电码
let CCCHandler = null; 
if (typeof CCC_TABLE !== 'undefined') { 
    CCCHandler = { 
        codeTable: CCC_TABLE || [],
        convert(text) {
            if (this.codeTable.length === 0) {return "电码表未正确加载";}
            if (/^[\d\s]+$/.test(text.trim())) {return this.decode(text);} 
            else {return this.encode(text);}
            },
        decode(codeText) {
            const codes = codeText.trim().split(/\s+/); let result = "";
            for (const code of codes) {const char = this.findCharByCode(code);if (!char) return `无效电码 ${code}`;result += char;}
            return `${result}`;
            },
        encode(chineseText) {
            let result = "";
            for (const char of chineseText) {const code = this.findCodeByChar(char);if (!code) return `未找到「${char}」对应电码`;result += `${code} `;}
            return `${result.trim()}`;
            },
        findCharByCode(inputCode) {
            const codeStr = inputCode.toString().replace(/^0+/, '');
            if (codeStr === '') return null; const targetCode = parseInt(codeStr, 10);
            if (isNaN(targetCode)) return null;
            return this.codeTable.find(item => item.CCCnumber === targetCode)?.CCCCharacter || null;
            },
        findCodeByChar(char) {
            const entry = this.codeTable.find(item => item.CCCCharacter === char);
            if (!entry) return null; return entry.CCCnumber.toString().padStart(4, '0');
            }
        };
    }
if (typeof CCC_TABLE === 'undefined') {document.getElementById('cccResult').textContent =`中文电码功能加载失败`;}

// ROT转换
class ROTCipher {
	static rot5(text) {
		return text.split('').map(char => {
			if (char.match(/[0-9]/)) {
				return String.fromCharCode(((char.charCodeAt(0) - 48 + 5) % 10) + 48);}	
			return char;	
        }).join('');}
	static rot13(text) {
		return text.split('').map(char => {
			if (char.match(/[a-zA-Z]/)) {
				const code = char.charCodeAt(0);
				const isUpperCase = code >= 65 && code <= 90;
				const base = isUpperCase ? 65 : 97;
				return String.fromCharCode(((code - base + 13) % 26) + base);}	
			return char;	
        }).join('');}
	static rot18(text) {return ROTCipher.rot5(ROTCipher.rot13(text));}
	static rot47(text) {return text.split('').map(char => {const code = char.charCodeAt(0);
			if (code >= 33 && code <= 126) {return String.fromCharCode(((code - 33 + 47) % 94) + 33);}	
			return char;	
        }).join('');}
	static encrypt(text, type) {
		switch (type) {
			case 'char': return ROTCipher.rot5(text);
			case 'dec':  return ROTCipher.rot13(text);
			case 'hex':  return ROTCipher.rot18(text);
			case 'oct':  return ROTCipher.rot47(text);
			default: return text; }}
	static decrypt(text, type) {
        return ROTCipher.encrypt(text, type);}}


        